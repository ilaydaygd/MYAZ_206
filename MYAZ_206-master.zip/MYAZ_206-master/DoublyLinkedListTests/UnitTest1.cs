using System;
using Xunit;

namespace DoublyLinkedListTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
