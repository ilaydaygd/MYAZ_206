﻿using System;

namespace RecordTypeTest
{
    public record RecordType
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}
